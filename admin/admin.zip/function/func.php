<?php
    function loadClass($c){
      include ADROOT."/class/".$c.".class.php";
    }
 ?>
