<div class="footer text-sm-center">
  <div class="container">
          <a href='#'><i class="fa fa-twitch fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-facebook fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-twitter fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-youtube-play fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-rss fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-vine fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-flickr fa-1x fa-fw"></i></a>
          <a href='#'><i class="fa fa-linkedin fa-1x fa-fw"></i></a>
        </span>
        <p>Email : baotuongtrading@gmail.com</p>
        <p>Hotline : 0937 28 48 26</p>
  </div>
</div>
